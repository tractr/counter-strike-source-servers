TeamChange

Change team with /spec, /t, /ct commands.
In CS:GO it is hard to change team especialy in DM mode. 
This plugin will help.
