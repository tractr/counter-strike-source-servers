new State:ConfigState = CONFIG_STATE_NONE;
new Prune = 30;
new g_cfgHandicapTopRank = 10;
new bool:g_Cfg_DontAddWinsOnBot = false;
