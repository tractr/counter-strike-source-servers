/* Weapon index lookup kv */
new String:WeaponFile[PLATFORM_MAX_PATH];
new Handle:KvWeapon = INVALID_HANDLE;
new bool:WeaponOpen;
new Handle:TrieWeapon = INVALID_HANDLE;
