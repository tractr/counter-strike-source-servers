// Offset
new OffsetMoney;
new OffsetArmor;
new OffsetHelm;
new OffsetDefuser;
new OffsetMovement;
new OffsetHostage;
new m_hMyWeapons;
new OffsetWeaponParent;
new g_iOffs_iPrimaryAmmoType = INVALID_OFFSET;
new g_iOffsetAmmo;
