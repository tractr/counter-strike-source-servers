<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>GunGame Winner</title>
    </head>
<body>
    <script type="text/javascript">
        window.open('gungame_winner.php?<?php echo $_SERVER['QUERY_STRING']; ?>', 'ggwin', false);
    </script>
</body>
</html>
